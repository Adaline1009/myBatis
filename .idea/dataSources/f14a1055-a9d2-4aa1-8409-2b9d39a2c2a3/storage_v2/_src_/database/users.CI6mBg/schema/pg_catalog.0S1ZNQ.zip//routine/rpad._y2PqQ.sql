CREATE FUNCTION rpad(text, integer)
  RETURNS text
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.rpad($1, $2, ' ')
$$;

