CREATE FUNCTION newid()
  RETURNS uuid
LANGUAGE SQL
AS $$
select uuid_generate_v1();
$$;

